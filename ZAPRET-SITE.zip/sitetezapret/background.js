const REDIRECT_URL = "https://www.google.com/search?q=time+to+work";
const RULE_ID = 1;

// --- 1. Функция, которая генерирует правила блокировки ---
function generateRules(blockedSites, isEnabled) {
    if (!isEnabled || blockedSites.length === 0) {
        return [];
    }
    
    // Преобразуем список доменов в правила
    const rules = blockedSites.map((site, index) => ({
        id: RULE_ID + index, // Каждое правило должно иметь уникальный ID
        priority: 1,
        action: {
            type: "redirect",
            redirect: { url: REDIRECT_URL }
        },
        condition: {
            urlFilter: `*://*${site}/*`, // Шаблон для блокировки сайта
            resourceTypes: [
                "main_frame" // Блокировать только при переходе на новую страницу
            ]
        }
    }));
    
    return rules;
}

// --- 2. Функция, которая применяет правила в Chrome ---
function updateBlockingRules(blockedSites, isEnabled) {
    const newRules = generateRules(blockedSites, isEnabled);
    
    // Получаем текущее состояние правил, чтобы знать, какие удалить
    chrome.declarativeNetRequest.getDynamicRules((currentRules) => {
        const currentRuleIds = currentRules.map(rule => rule.id);

        chrome.declarativeNetRequest.updateDynamicRules({
            removeRuleIds: currentRuleIds, // Удаляем все старые правила
            addRules: newRules // Добавляем новые правила
        }, () => {
            if (chrome.runtime.lastError) {
                console.error("Error updating rules:", chrome.runtime.lastError.message);
            } else {
                console.log(`Blocking rules updated. Total rules: ${newRules.length}`);
            }
        });
    });
}

// --- 3. Инициализация и Прослушивание сообщений от popup.js ---
chrome.runtime.onInstalled.addListener(() => {
    // Устанавливаем настройки по умолчанию
    const defaultBlockedSites = ["facebook.com", "vk.com", "youtube.com", "instagram.com"];
    chrome.storage.local.set({ blockedSites: defaultBlockedSites, isEnabled: true }, () => {
        // Применяем правила сразу после установки
        updateBlockingRules(defaultBlockedSites, true);
    });
});

// Прослушиваем сообщения из popup.js (при нажатии "Сохранить" или "Включить/Выключить")
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === "updateRules") {
        updateBlockingRules(request.blockedSites, request.isEnabled);
        sendResponse({status: "Rules updated"});
    }
});