// (Содержимое popup.js остается таким же, как в предыдущем ответе)
document.addEventListener('DOMContentLoaded', () => {
    const sitesTextArea = document.getElementById('sites');
    const saveButton = document.getElementById('saveButton');
    const toggleButton = document.getElementById('toggleButton');
    const statusText = document.getElementById('statusText');

    function updateStatus(isEnabled) {
        if (isEnabled) {
            statusText.textContent = 'ВКЛЮЧЕНО';
            statusText.className = 'on';
            toggleButton.textContent = 'Выключить';
        } else {
            statusText.textContent = 'ВЫКЛЮЧЕНО';
            statusText.className = 'off';
            toggleButton.textContent = 'Включить';
        }
    }

    function loadSettings() {
        chrome.storage.local.get(['blockedSites', 'isEnabled'], (data) => {
            if (data.blockedSites) {
                sitesTextArea.value = data.blockedSites.join('\n');
            }
            updateStatus(data.isEnabled);
        });
    }

    function sendRulesUpdate(blockedSites, isEnabled, callback) {
        chrome.runtime.sendMessage({
            action: "updateRules",
            blockedSites: blockedSites,
            isEnabled: isEnabled
        }, callback);
    }

    saveButton.addEventListener('click', () => {
        const sitesArray = sitesTextArea.value
            .split('\n')
            .map(site => site.trim())
            .filter(site => site.length > 0);

        chrome.storage.local.get('isEnabled', (data) => {
            const isEnabled = data.isEnabled !== undefined ? data.isEnabled : true;
            
            chrome.storage.local.set({ blockedSites: sitesArray }, () => {
                sendRulesUpdate(sitesArray, isEnabled, () => {
                     alert('Список сохранен и правила блокировки обновлены!');
                });
            });
        });
    });

    toggleButton.addEventListener('click', () => {
        chrome.storage.local.get(['blockedSites', 'isEnabled'], (data) => {
            const newStatus = !data.isEnabled;
            const blockedSites = data.blockedSites || [];
            
            chrome.storage.local.set({ isEnabled: newStatus }, () => {
                sendRulesUpdate(blockedSites, newStatus, () => {
                    updateStatus(newStatus);
                });
            });
        });
    });

    loadSettings();
});